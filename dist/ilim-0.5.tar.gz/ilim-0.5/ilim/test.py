from formater import make_format
print(make_format('Хай','m-p'))